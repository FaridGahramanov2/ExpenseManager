//
//  ExpenseManagerApp.swift
//  ExpenseManager
//
//  Created by Farid Gahramanov on 16.09.23.
//

import SwiftUI

@main
struct ExpenseManagerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
